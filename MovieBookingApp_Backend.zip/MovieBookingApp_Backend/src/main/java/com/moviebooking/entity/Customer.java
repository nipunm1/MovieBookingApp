package com.moviebooking.entity;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

//import javax.validation.constraints.Email;
//import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Document(collection = "customers")
public class Customer {

    @Transient
    public static final String SEQUENCE_NAME = "customer_id_sequence";

    @NotNull(message = "firstName cannot be null")
    @NotBlank(message = "firstName must be given")
    private String firstName;
    @NotNull(message = "lastName cannot be null")
    @NotBlank(message = "lastName must be given")
    private String lastName;
    @NotNull(message = "emailId cannot be null")
    @NotBlank(message = "emailId must be given")
    @Email(message = "check your email")
    private String emailId;

    @Id
    private int loginId;


    @NotNull(message = "userName cannot be null")
    @NotBlank(message = "userName must be given")
    private String userName;


    @NotNull(message = "password cannot be null")
    @NotBlank(message = "password must be given")
    private String password;

    @NotNull(message = "confirmPassword cannot be null")
    @NotBlank(message = "confirmPassword must be given")
    private String confirmPassword;
    @NotNull(message = "contactNo cannot be null")
    private long contactNo;

    private String role="user";

	public Customer(String string, String string2, String string3, int i, String string4, String string5,
			String string6, int j, String string7) {
		
	}

	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public String getUserName() {
		// TODO Auto-generated method stub
		return this.userName;
	}

	public String getPassword() {
		// TODO Auto-generated method stub
		return this.password;
	}

	public String getRole() {
		// TODO Auto-generated method stub
		return this.role;
	}

	public String getEmailId() {
		// TODO Auto-generated method stub
		return this.emailId;
	}

	public int getLoginId() {
		// TODO Auto-generated method stub
		return this.loginId;
	}

	public String getConfirmPassword() {
		// TODO Auto-generated method stub
		return this.confirmPassword;
	}

	public void setPassword(String encode) {
		// TODO Auto-generated method stub
		this.password = encode;
	}

	public void setLoginId(int sequenceNumber) {
		// TODO Auto-generated method stub
		this.loginId = sequenceNumber;
	}

	public void setConfirmPassword(String encode) {
		// TODO Auto-generated method stub
		this.confirmPassword = encode;
	}

	public void setFirstName(String string) {
		// TODO Auto-generated method stub
		this.firstName = string;
	}

	public String getFirstName() {
		// TODO Auto-generated method stub
		return this.firstName;
	}

	public void setLastName(String string) {
		// TODO Auto-generated method stub
		this.lastName = string;
	}

	public String getLastName() {
		// TODO Auto-generated method stub
		return this.lastName;
	}

	public void setEmailId(String string) {
		// TODO Auto-generated method stub
		this.emailId = string;
	}

	public void setUserName(String string) {
		// TODO Auto-generated method stub
		this.userName = string;
	}

	public void setContactNo(long i) {
		// TODO Auto-generated method stub
		this.contactNo = i;
	}

	public long getContactNo() {
		// TODO Auto-generated method stub
		return this.contactNo;
	}

	public void setRole(String string) {
		// TODO Auto-generated method stub
		this.role = string;
	}
	
	
	
}
