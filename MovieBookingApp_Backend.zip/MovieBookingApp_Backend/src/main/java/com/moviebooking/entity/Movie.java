package com.moviebooking.entity;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "movies")
public class Movie {

    @Transient
    public static final String SEQUENCE_NAME="movie_sequence";
    @Id
    private MovieId movieId;
    private int id;
    private String imageUrl="https://img.freepik.com/premium-vector/abstract-home-cinema-background-illustration_118124-3052.jpg?w=360";
    @NotNull(message = "costOfTicket cannot be null")
    private double costOfTicket;
    @NotNull(message = "noOfTicketsAllotted cannot be null")
    private int noOfTicketsAllotted;
    private int noOfTicketsSold;
    private String ticketStatus="Book ASAP";
	public Movie(MovieId movieId2, int i, double d, int j, int k, String string) {
		// TODO Auto-generated constructor stub
	}
	public Movie() {
		// TODO Auto-generated constructor stub
	}
	public MovieId getMovieId() {
		// TODO Auto-generated method stub
		return this.movieId;
	}
	public int getNoOfTicketsAllotted() {
		// TODO Auto-generated method stub
		return this.noOfTicketsAllotted;
	}
	public void setId(int sequenceNumber) {
		// TODO Auto-generated method stub
		this.id = sequenceNumber;
	}
	public double getCostOfTicket() {
		// TODO Auto-generated method stub
		return this.costOfTicket;
	}
	public void setCostOfTicket(double costOfTicket2) {
		// TODO Auto-generated method stub
		this.costOfTicket = costOfTicket2;
	}
	public int getNoOfTicketsSold() {
		// TODO Auto-generated method stub
		return this.noOfTicketsSold;
	}
	public void setTicketStatus(String string) {
		// TODO Auto-generated method stub
		this.ticketStatus = string;
	}
	
	public int getId() {
		// TODO Auto-generated method stub
		return this.id;
	}
	public void setNoOfTicketsSold(int i) {
		// TODO Auto-generated method stub
		this.noOfTicketsSold = i;
	}
	public void setMovieId(MovieId movieId2) {
		// TODO Auto-generated method stub
		this.movieId = movieId2;
	}
	public void setNoOfTicketsAllotted(int i) {
		// TODO Auto-generated method stub
		this.noOfTicketsAllotted = i;
	}
	public String getTicketStatus() {
		// TODO Auto-generated method stub
		return this.ticketStatus;
	}

}
