package com.moviebooking.entity;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document(collection = "tickets")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Ticket {

    @Transient
    public static final String SEQUENCE_NAME="ticket_sequence";
    @Id
    private int ticketId;

    //public enum ShowName {MorningShow,Matinee,FirstShow,SecondShow} ;
    @NotNull(message = "movieName cannot be null")
    private String movieName;
    @NotNull(message = "theatreName cannot be null")
    private String theatreName;

    private double totalCost;
    @NotNull(message = "noOfTickets cannot be null")
    private int noOfTickets;
    @NotNull(message = "seats cannot be null")
    private List<Seat> seats;

    private Customer customer;

	public Ticket(int i, String string, String string2, double d, int j, List<Seat> seats2, Customer customer2) {
		// TODO Auto-generated constructor stub
	}

	public Ticket() {
		// TODO Auto-generated constructor stub
	}

	public int getTicketId() {
		// TODO Auto-generated method stub
		return this.ticketId;
	}

	public void setCustomer(Customer customer2) {
		// TODO Auto-generated method stub
		this.customer = customer2;
	}

	public String getMovieName() {
		// TODO Auto-generated method stub
		return this.movieName;
	}

	public String getTheatreName() {
		// TODO Auto-generated method stub
		return this.theatreName;
	}

	public int getNoOfTickets() {
		// TODO Auto-generated method stub
		return this.noOfTickets;
	}

	public List<Seat> getSeats() {
		// TODO Auto-generated method stub
		return this.seats;
	}

	public void setSeats(List<Seat> seats2) {
		// TODO Auto-generated method stub
		this.seats = seats2;
	}

	public void setTicketId(int sequenceNumber) {
		// TODO Auto-generated method stub
		this.ticketId = sequenceNumber;
	}

	public void setTotalCost(double d) {
		// TODO Auto-generated method stub
		this.totalCost = d;
	}

	public void setMovieName(String string) {
		// TODO Auto-generated method stub
		this.movieName = string;
	}

	public void setTheatreName(String string) {
		// TODO Auto-generated method stub
		this.theatreName = string;
	}

	public double getTotalCost() {
		// TODO Auto-generated method stub
		return this.totalCost;
	}

	public void setNoOfTickets(int i) {
		// TODO Auto-generated method stub
		this.noOfTickets = i;
	}

	
	
}
