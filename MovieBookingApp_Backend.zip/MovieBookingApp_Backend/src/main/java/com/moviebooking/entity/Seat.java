package com.moviebooking.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "seat")
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Seat {

    @Transient
    public static final String SEQUENCE_NAME="seat_sequence";
    @Id
    private int seatId;
    private int seatNumber;
    private String seatType;
    private SeatStatus seatStatus;
    private double cost;
    private Movie movie;

    public Seat(int i, int j, String string, SeatStatus available, double d, Movie movie2) {
		// TODO Auto-generated constructor stub
    	this.seatId = i;
    	this.seatNumber = j;
    	this.seatType = string;
    	this.seatStatus = available;
    	this.cost = d;
    	this.movie = movie2;
    }

	public Seat() {
		// TODO Auto-generated constructor stub
	}

	public void setMovie(Movie movie) {
        this.movie = movie;
    }

    public void setSeatId(int seatId) {
        this.seatId = seatId;
    }

    public void setSeatNumber(int seatNumber) {
        this.seatNumber = seatNumber;
    }

    public void setSeatType() {
        if(this.seatNumber>0 && this.seatNumber<60){
            this.seatType="Balcony";
        }else{
            this.seatType="Orchestra";
        }

    }

    public void setSeatStatus(SeatStatus seatStatus) {
        this.seatStatus = seatStatus;
    }

    public void setCost() {
        if(this.seatType.equalsIgnoreCase("Orchestra")){
            this.cost=100;
        } else if (this.seatType.equalsIgnoreCase("Balcony")) {
            this.cost=50;
        }
    }

	public int getSeatNumber() {
		// TODO Auto-generated method stub
		return this.seatNumber;
	}

	public SeatStatus getSeatStatus() {
		// TODO Auto-generated method stub
		return this.seatStatus;
	}

	public double getCost() {
		// TODO Auto-generated method stub
		return this.cost;
	}
}
