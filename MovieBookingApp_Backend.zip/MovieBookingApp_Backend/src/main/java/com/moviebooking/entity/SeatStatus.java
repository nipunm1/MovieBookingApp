package com.moviebooking.entity;

public enum SeatStatus {Available,Booked,Selected}
