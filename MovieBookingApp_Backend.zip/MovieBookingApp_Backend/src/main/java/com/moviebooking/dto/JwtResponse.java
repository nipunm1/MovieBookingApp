package com.moviebooking.dto;

import com.moviebooking.entity.Customer;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class JwtResponse {
    public JwtResponse(Customer customer2, String token2) {
		// TODO Auto-generated constructor stub
    	this.customer = customer2;
    	this.token = token2;
	}
	private Customer customer;
    private String token;
}
