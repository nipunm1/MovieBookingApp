package com.moviebooking.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ForgotPassword {
    private String password;
    private String confirmPassword;
	public String getPassword() {
		// TODO Auto-generated method stub
		return this.password;
	}
	public String getConfirmPassword() {
		// TODO Auto-generated method stub
		return this.confirmPassword;
	}
	
}
