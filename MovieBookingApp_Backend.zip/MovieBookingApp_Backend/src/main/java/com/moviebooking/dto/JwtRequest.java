package com.moviebooking.dto;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class JwtRequest {
    private String userName;
    private String password;
	public String getUserName() {
		// TODO Auto-generated method stub
		return this.userName;
	}
	public String getPassword() {
		// TODO Auto-generated method stub
		return this.password;
	}
	
	
}
